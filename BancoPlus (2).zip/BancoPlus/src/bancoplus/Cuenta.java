package bancoplus;

import bancoplus.excepciones.SaldoExcedidoException;

/**
 * Representa las cuentas de banco de los usuarios
 * @author itson
 */
public class Cuenta extends SaldoExcedidoException{
    private final String numero;
    private float saldo;

    public Cuenta(String numero, float saldo) {
        this.numero = numero;
        this.saldo = saldo;
    }


    public String getNumero() {
        return numero;
    }

    public float getSaldo() {
        return saldo;
    }
    
    public void restarFondos(float cantidad){
        this.saldo -= cantidad;
    }
    
    public void sumarFondos(float cantidad){
        this.saldo += cantidad;
    }
    
    public void depositar(float cantidad) throws SaldoExcedidoException {
        if (saldo + cantidad > 5000 ) {
            throw new SaldoExcedidoException("excede el limite del saldo ");
        }
        saldo += cantidad;
    }

    void setSaldo(double nuevoSaldo) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
