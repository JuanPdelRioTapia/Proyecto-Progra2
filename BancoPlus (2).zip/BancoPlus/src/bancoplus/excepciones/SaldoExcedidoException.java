/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bancoplus.excepciones;

/**
 *
 * @author PC
 */
public class SaldoExcedidoException extends Exception {
    
    public SaldoExcedidoException(){
        super("es saldo no puede exceder de los 5000");
    }
    
    public SaldoExcedidoException(String mensaje){
        super(mensaje);
    }
        
    
}
