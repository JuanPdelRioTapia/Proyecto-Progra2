/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bancoplus.excepciones;

/**
 *
 * @author PC
 */
public class DepositoNegativoException  extends Exception{
    
    public DepositoNegativoException(){
        super("la cantidad a depositar no puede ser negativa");
    }
    
    public DepositoNegativoException(String mensaje){
        super(mensaje);
    }
    
}
