package bancoplus;

import bancoplus.excepciones.CuentaNoEncontradaException;
import bancoplus.excepciones.DepositoNegativoException;
import bancoplus.excepciones.SaldoExcedidoException;
import bancoplus.excepciones.SaldoInsuficienteException;
import java.util.LinkedList;
import java.util.List;

/**
 * Realiza las operaciones bancarias entre las diferentes cuentas
 * @author itson
 */
public class Banco {
    
    /* Cuentas disponibles del banco 
    * Nota: Se utiliza una colección para simplificar las operaciones
    * Este tema es el siguiente de estudiar en la materia
    */
    private final List<Cuenta> cuentas;

    /**
     * Construye un objeto banco con las cuentas disponibles
     * No es necesario aplicar ninguna validación a este método
     */
    public Banco() {
        this.cuentas = new LinkedList<>();
        this.cuentas.add(new Cuenta("1111", 1000));
        this.cuentas.add(new Cuenta("2222", 500));
        this.cuentas.add(new Cuenta("3333", 2000));
    }
    
    /***
     * Recupera una cuenta utilizando un número asociado
     * No es necesario aplicar ninguna validación a este método
     * @param numeroCuenta número de cuenta que deseas buscar
     * @return número de cuenta asociada o null si no encuentra nada
     */
    private Cuenta recuperarCuenta(String numeroCuenta) throws CuentaNoEncontradaException{
        if(numeroCuenta.length() != 4) {
            throw new CuentaNoEncontradaException("el numero de cuenta debe tener cuatro dígitos");
        }
        Cuenta cuentaRecuperada = this.cuentas.stream()
                            .filter(cuenta -> cuenta.getNumero().equals(numeroCuenta))
                            .findAny()
                            .orElse(null);
        if (cuentaRecuperada == null) {
            throw new CuentaNoEncontradaException("la cuenta con el numero " + numeroCuenta + " no se encontro");
        }
        return cuentaRecuperada;
    }
    
    public Cuenta depositar(String numeroCuenta, float cantidad) throws SaldoExcedidoException, CuentaNoEncontradaException, DepositoNegativoException { 
        if (cantidad < 0) {
            throw new DepositoNegativoException("la cantidad a depositar no puede ser negativa.");
        }
        Cuenta cuenta = recuperarCuenta(numeroCuenta);
        double nuevoSaldo = cuenta.getSaldo() + cantidad;
        if (nuevoSaldo > 5000) {
            throw new SaldoExcedidoException("el saldo no se puede exceder de los 5000");
        }
        cuenta.setSaldo(nuevoSaldo);
        return cuenta;
    }

    public Cuenta retirar(String numeroCuenta, float cantidad) throws SaldoInsuficienteException, CuentaNoEncontradaException {
        Cuenta cuenta = this.recuperarCuenta(numeroCuenta);
        float saldonuevo = cuenta.getSaldo() - cantidad;
        if (saldonuevo < 0){
            throw new SaldoInsuficienteException("saldo insuficiente para realizar el retiro");
        }
        cuenta.restarFondos(cantidad);
        return cuenta;
    }
}
