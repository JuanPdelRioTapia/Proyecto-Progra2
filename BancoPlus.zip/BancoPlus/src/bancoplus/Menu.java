package bancoplus;

import bancoplus.excepciones.CuentaNoEncontradaException;
import bancoplus.excepciones.SaldoExcedidoException;
import bancoplus.excepciones.SaldoInsuficienteException;
import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.Random;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Maneja el flujo de control del sistema
 * @author itson
 */
public class Menu {

    private final static Scanner scanner = new Scanner(System.in);  
    private final static Banco banco = new Banco();
    
    public static void main(String[] args) throws SaldoExcedidoException, SaldoInsuficienteException, CuentaNoEncontradaException, SaldoExcedidoException {        
        // Soluciona el problema de caracteres especiales mostrados incorrectamente 
        if (!"UTF-8".equals(java.nio.charset.Charset.defaultCharset().displayName())) {
            System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out), true, StandardCharsets.UTF_8));
        }
        
        while (true) {
            System.out.println("\nSeleccione una opción:");
            System.out.println("1. Depositar");
            System.out.println("2. Transferencia");
            System.out.println("3. Retirar");
            System.out.println("4. Salir");

            int opcion = scanner.nextInt();

            switch (opcion) {
                case 1 -> {
                    solicitarDeposito();
                }
                case 2 -> {
                    solicitarTransferencia();
                    }
                case 3 -> {
                    solicitarRetiro();
                }
                case 4 -> {
                    solicitarSalir();
                }
                default -> System.out.println("Opción no válida. Por favor, seleccione una opción válida.");
            }
        }
    }
    
    private static void solicitarDeposito() throws SaldoExcedidoException, CuentaNoEncontradaException, SaldoInsuficienteException {
        System.out.print("\nIngrese el número de cuenta destino: ");
        String cuentaDestino = scanner.next();
        System.out.print("Ingrese la cantidad a depositar: ");
        float cantidadDeposito = scanner.nextFloat();
        Cuenta cuenta = banco.depositar(cuentaDestino, cantidadDeposito);
        System.out.println("Depósito realizado. Saldo actual: " + cuenta.getSaldo());
    }
    
    private static void solicitarRetiro() throws SaldoInsuficienteException, CuentaNoEncontradaException{
        System.out.print("\nIngrese el número de cuenta destino: ");
        String cuentaDestino = scanner.next();
        System.out.print("Ingrese la cantidad a retirar: ");
        float cantidadRetiro = scanner.nextFloat();
        Cuenta cuenta = banco.retirar(cuentaDestino, cantidadRetiro);
        System.out.println("Retiro realizado. Saldo actual: " + cuenta.getSaldo());
    }
     
    
    private static void solicitarSalir(){
        System.out.println("\nGracias por utilizar nuestros servicios.");
        System.exit(0);
    }
    
    private static void solicitarTransferencia() throws CuentaNoEncontradaException, SaldoExcedidoException {
        System.out.print("\nIngrese el número de cuenta del Mandatario: ");
        String cuentaMandatario = scanner.next();
        
        System.out.print("\nIngrese el número de cuenta destino: ");
        String cuentaDestino = scanner.next();
        
        System.out.print("Ingrese la cantidad a depositar: ");
        float cantidadDeposito = scanner.nextFloat();
                
        System.out.println("**** Transferencia exitosa ****");
        Random random = new Random();
        int codigoAleatorio = random.nextInt();
        System.out.println("Codigo: " + codigoAleatorio);
        Date fechaActual = new Date();
        System.out.println("Realizada el dia " + fechaActual);
        System.out.println("Cuenta Origen: "+cuentaMandatario+"--------> Cuenta Destino: " + cuentaDestino);
        System.out.println("Cantidad transferida: "+cantidadDeposito);
    }
    
    
    
}
