/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bancoplus.excepciones;

/**
 *
 * @author PC
 */
public class SaldoInsuficienteException extends Exception{
    
    public SaldoInsuficienteException(){
        super("no puedes retirar ya que no tienes saldo");
        
    }
    
    public SaldoInsuficienteException(String mensaje) {
        super(mensaje);
    }
}
