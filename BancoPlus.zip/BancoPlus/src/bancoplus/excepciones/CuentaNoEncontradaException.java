/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bancoplus.excepciones;

/**
 *
 * @author PC
 */
public class CuentaNoEncontradaException extends Exception   {
    public CuentaNoEncontradaException() {
        super("La cuenta especificada no ha sido encontrada.");
    }
    
    public CuentaNoEncontradaException(String mensaje) {
        super(mensaje);
    }
}
